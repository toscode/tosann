﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Collections.Specialized;
using System.Windows.Forms;
using System.Data.OleDb;


namespace final_touch
{
    public partial class Form1 : Form

    {
        String p = "";
        String amountToWithdraw;
        String amountTrans;
        String bankName;
        String accountNo;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SCREEN2.Visible = false;
            screen3.Visible = false;
            screen4.Visible = false;
            screen5.Visible = false;
            screen6.Visible = false;
            Screen7.Visible = false;
            screen8.Visible = false;
            screen9.Visible = false;
            screen10.Visible = false;
            screen11.Visible = false;
            screen12.Visible = false;

        }

        private void button11_Click(object sender, EventArgs e)
        {
            textbox1.Text = "";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "1";
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "3";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "5";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "6";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "7";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "9";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "0";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("confirm you want to exit ", "ATM system", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);

            p = textbox1.Text;

            
            string strSql = "select* from Users where pin=" + textbox1.Text + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);
            connection.Open();
            OleDbDataReader reader;
            int count = 0;
            reader = comman.ExecuteReader();
            try
            {

                while (reader.Read())
                {
                    count = count + 1;

                }
            }
            catch
            {

            }

            if (count == 1)
            {
                screen3.Visible = true;
                
            }
            else
            {

                invalid.Text = "INVAILD PIN";
                textbox1.Text = "";
            }

            reader.Close();
            connection.Close();
            textbox1.Text = "";
        }

        private void button32_Click(object sender, EventArgs e)
        {
            SCREEN2.Visible = true;
        }

        public void SCREEN2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);

            p = textbox1.Text;


            string strSql = "select* from Users where pin=" + textbox1.Text + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);
            connection.Open();
            OleDbDataReader reader;
            int count = 0;
            reader = comman.ExecuteReader();
            try
            {

                while (reader.Read())
                {
                    count = count + 1;

                }
            }
            catch
            {

            }

            if (count == 1)
            {
                screen3.Visible = true;

            }
            else
            {

                invalid.Text = "INVAILD PIN";
                textbox1.Text = "";
            }

            reader.Close();
            connection.Close();
            textbox1.Text = "";
        }

        private void button25_Click(object sender, EventArgs e)
        {
            screen4.Visible = true;
        }

        private void button36_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);



            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);
            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();

            String balance = "";
            String name = "";

            while (reader.Read())
            {
                name = reader["NAME"].ToString();
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString()  + reader["NAME"].ToString() + "LOCATION = FUPRE");
            }
            MessageBox.Show(" Avaliable balance =  " + balance + " " + name + "  LOCATION = FUPRE");
        }

        private void button33_Click(object sender, EventArgs e)
        {
            screen5.Visible = true;
            screen6.Visible = false;
            Screen7.Visible = false;
            screen8.Visible = false;
        }

        private void button39_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);

            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();
            String balance = "";

            while (reader.Read())
            {
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }
            int bal = int.Parse(balance);
            if (bal > 500)
            {
                int newAmount = bal - 500;
                try
                {

                    OleDbConnection connection2 = new OleDbConnection(connectionString);
                    strSql = "update Users set account_balance = " + newAmount.ToString() + " where pin= " + p + " ";
                    connection2.Open();
                    OleDbCommand comman2 = new OleDbCommand(strSql, connection2);
                    comman2.ExecuteNonQuery();
                    screen6.Visible = true;
                   

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
            reader.Close();
        }

        private void button40_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);

            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();
            String balance = "";

            while (reader.Read())
            {
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }
            int bal = int.Parse(balance);
            if (bal > 1000)
            {
                int newAmount = bal - 1000;
                try
                {

                    OleDbConnection connection2 = new OleDbConnection(connectionString);
                    strSql = "update Users set account_balance = " + newAmount.ToString() + " where pin= " + p + " ";
                    connection2.Open();
                    OleDbCommand comman2 = new OleDbCommand(strSql, connection2);
                    comman2.ExecuteNonQuery();
                    screen6.Visible = true;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
            reader.Close();
        }

        private void button41_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);

            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();
            String balance = "";

            while (reader.Read())
            {
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }
            int bal = int.Parse(balance);
            if (bal > 2000)
            {
                int newAmount = bal - 2000;
                try
                {

                    OleDbConnection connection2 = new OleDbConnection(connectionString);
                    strSql = "update Users set account_balance = " + newAmount.ToString() + " where pin= " + p + " ";
                    connection2.Open();
                    OleDbCommand comman2 = new OleDbCommand(strSql, connection2);
                    comman2.ExecuteNonQuery();
                    screen6.Visible = true;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
            reader.Close();
        }

        private void button42_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);

            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();
            String balance = "";

            while (reader.Read())
            {
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }
            int bal = int.Parse(balance);
            if (bal > 5000)
            {
                int newAmount = bal - 5000;
                try
                {

                    OleDbConnection connection2 = new OleDbConnection(connectionString);
                    strSql = "update Users set account_balance = " + newAmount.ToString() + " where pin= " + p + " ";
                    connection2.Open();
                    OleDbCommand comman2 = new OleDbCommand(strSql, connection2);
                    comman2.ExecuteNonQuery();
                    screen6.Visible = true;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
            reader.Close();
        }

        private void button43_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);

            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();
            String balance = "";

            while (reader.Read())
            {
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }
            int bal = int.Parse(balance);
            if (bal > 10000)
            {
                int newAmount = bal - 10000;
                try
                {

                    OleDbConnection connection2 = new OleDbConnection(connectionString);
                    strSql = "update Users set account_balance = " + newAmount.ToString() + " where pin= " + p + " ";
                    connection2.Open();
                    OleDbCommand comman2 = new OleDbCommand(strSql, connection2);
                    comman2.ExecuteNonQuery();
                    screen6.Visible = true;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
            reader.Close();
        }

        private void button44_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);

            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();
            String balance = "";

            while (reader.Read())
            {
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }
            int bal = int.Parse(balance);
            if (bal > 20000)
            {
                int newAmount = bal - 20000;
                try
                {

                    OleDbConnection connection2 = new OleDbConnection(connectionString);
                    strSql = "update Users set account_balance = " + newAmount.ToString() + " where pin= " + p + " ";
                    connection2.Open();
                    OleDbCommand comman2 = new OleDbCommand(strSql, connection2);
                    comman2.ExecuteNonQuery();
                    screen6.Visible = true;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
            reader.Close();
        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void button50_Click(object sender, EventArgs e)
        {

            SCREEN1.Visible = true;
            screen3.Visible = false;
            screen4.Visible = false;
            screen5.Visible = false;
            screen6.Visible = false;
            SCREEN2.Visible = false;
            tanks.Text = "Thank for banking with us";
            transactionss.Visible = false;
            anotherT.Visible = false;



        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {
            transactionss.Text = "Transaction Successful";
            anotherT.Text = "Do another transaction";
        }

        private void transactionss_Click(object sender, EventArgs e)
        {

        }

        private void button49_Click(object sender, EventArgs e)
        {
            SCREEN1.Visible = true;
            screen3.Visible = false;
            screen4.Visible = false;
            screen5.Visible = false;
            screen6.Visible = false;
            SCREEN2.Visible = false;
            transactionss.Visible =false;
            anotherT.Visible = false;
            

        }

        private void screen6_Paint(object sender, PaintEventArgs e)
        {
            transactionss.Visible = true;
            anotherT.Visible = true;
            tanks.Visible=true;
           
        }

        private void screen5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button37_Click(object sender, EventArgs e)
        {
            
        }

        private void button38_Click(object sender, EventArgs e)
        {
            Screen7.Visible = true;

        }

        private void button56_Click(object sender, EventArgs e)
        {
            screen8.Visible = true;
        }

        private void button62_Click(object sender, EventArgs e)
        {

            amountToWithdraw = airtimeamount.Text;
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);



            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);
            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();

            String balance = "";

            while (reader.Read())
            {
                balance = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }



            int bal = int.Parse(balance);
            int withdraw = int.Parse(amountToWithdraw);

            if (bal > withdraw)
            {
                screen6.Visible = true;
              
            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
        }

        private void screen8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button63_Click(object sender, EventArgs e)
        {
            bankName = "access";
            screen10.Visible=true;
        }

        private void button35_Click(object sender, EventArgs e)
        {
            screen9.Visible = true;
        }

        private void screen9_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button64_Click(object sender, EventArgs e)
        {
            bankName = "first_bank";
            screen10.Visible = true;
        }

        private void button65_Click(object sender, EventArgs e)
        {

            bankName = "zenith";

            screen10.Visible = true;
        }

        private void button66_Click(object sender, EventArgs e)
        {

            bankName = "GT";

            screen10.Visible = true;
        }

        private void button67_Click(object sender, EventArgs e)
        {

            bankName = "eco";

            screen10.Visible = true;
        }

        private void button68_Click(object sender, EventArgs e)
        {

            bankName = "polaris";

            screen10.Visible = true;
        }

        private void button74_Click(object sender, EventArgs e)
        {
            accountNo = EANTEXTBOX.Text;
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);


            string strSql = "select* from " + bankName + " where ACCOUNT_NUMBER=" + accountNo + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);
            connection.Open();
            OleDbDataReader reader;
            int count = 0;
            reader = comman.ExecuteReader();
            try
            {

                while (reader.Read())
                {
                    count = count + 1;

                }
            }
            catch
            {

            }

            if (count == 1)
            {


                screen11.Visible = true;
            }
            else
            {

                invalidaccountnum.Text = "invalid account number";
                EANTEXTBOX.Text = "";

            }

            reader.Close();
            connection.Close();

        }

        private void button86_Click(object sender, EventArgs e)
        {
            amountTrans = transferamounttextbox.Text;

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Peter\\Documents\\data1.accdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            string strSql = "select * from Users where pin=" + p + "";
            OleDbCommand comman = new OleDbCommand(strSql, connection);

            connection.Open();
            OleDbDataReader reader = comman.ExecuteReader();
            String trans = "";
            while (reader.Read())
            {
                trans = reader["account_balance"].ToString();
                Console.WriteLine("Account Bal = " + reader["account_balance"].ToString());
            }
            int bal = int.Parse(trans);
            int transs = int.Parse(amountTrans);
            if (bal > transs)
            {
                int newAmount = bal - transs;
                try
                {

                    OleDbConnection connection1 = new OleDbConnection(connectionString);
                    string strSql1 = "select * from " + bankName + " where ACCOUNT_NUMBER =" + accountNo + "";
                    OleDbCommand comman1 = new OleDbCommand(strSql1, connection1);

                    connection1.Open();
                    OleDbDataReader reader1 = comman1.ExecuteReader();
                    String trans1 = "";
                    while (reader1.Read())
                    {
                        trans1 = reader1["AMOUNT"].ToString();
                        Console.WriteLine("Account Bal = " + trans1);
                    }

                    int am = int.Parse(trans1);
                    int mon = am + transs;

                    OleDbConnection connection0 = new OleDbConnection(connectionString);
                    strSql1 = "update " + bankName + " set AMOUNT = " + mon.ToString() + " where ACCOUNT_NUMBER =" + accountNo + "";
                    connection0.Open();
                    OleDbCommand comman0 = new OleDbCommand(strSql1, connection0);
                    comman0.ExecuteNonQuery();


                    OleDbConnection connection2 = new OleDbConnection(connectionString);
                    strSql = "update Users set account_balance = " + newAmount.ToString() + " where pin= " + p + " ";
                    connection2.Open();
                    OleDbCommand comman2 = new OleDbCommand(strSql, connection2);
                    comman2.ExecuteNonQuery();
                    MessageBox.Show("Transaction successful");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
            else
            {
                MessageBox.Show("Insufficient Fund");
            }
            reader.Close();

        }
    }
}
