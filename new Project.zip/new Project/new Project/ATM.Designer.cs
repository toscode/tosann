﻿namespace new_Project
{
    partial class ATM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ATM));
            this.SCREEN2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.screen02 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.invalid = new System.Windows.Forms.Label();
            this.textbox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.screen4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.screen1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.another = new System.Windows.Forms.Panel();
            this.ascreen1 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.button38 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.screen5 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.wscreen1 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Tscreen2 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.Tscreen1 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.SCREEN2.SuspendLayout();
            this.screen02.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.screen4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.screen1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.another.SuspendLayout();
            this.ascreen1.SuspendLayout();
            this.screen5.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.wscreen1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.Tscreen2.SuspendLayout();
            this.panel11.SuspendLayout();
            this.Tscreen1.SuspendLayout();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // SCREEN2
            // 
            this.SCREEN2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.SCREEN2.Controls.Add(this.label1);
            this.SCREEN2.Controls.Add(this.button19);
            this.SCREEN2.Controls.Add(this.button14);
            this.SCREEN2.Controls.Add(this.button15);
            this.SCREEN2.Controls.Add(this.screen02);
            this.SCREEN2.Controls.Add(this.button16);
            this.SCREEN2.Controls.Add(this.button17);
            this.SCREEN2.Controls.Add(this.button18);
            this.SCREEN2.Controls.Add(this.panel2);
            this.SCREEN2.Location = new System.Drawing.Point(114, 24);
            this.SCREEN2.Name = "SCREEN2";
            this.SCREEN2.Size = new System.Drawing.Size(548, 290);
            this.SCREEN2.TabIndex = 54;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(232, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 24);
            this.label1.TabIndex = 20;
            this.label1.Text = "ATM";
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.DarkGray;
            this.button19.Image = ((System.Drawing.Image)(resources.GetObject("button19.Image")));
            this.button19.Location = new System.Drawing.Point(0, 50);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(108, 56);
            this.button19.TabIndex = 19;
            this.button19.Text = " ";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Silver;
            this.button14.Image = ((System.Drawing.Image)(resources.GetObject("button14.Image")));
            this.button14.Location = new System.Drawing.Point(0, 122);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(108, 56);
            this.button14.TabIndex = 14;
            this.button14.Text = " ";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Silver;
            this.button15.Image = ((System.Drawing.Image)(resources.GetObject("button15.Image")));
            this.button15.Location = new System.Drawing.Point(0, 197);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(108, 56);
            this.button15.TabIndex = 15;
            this.button15.Text = " ";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // screen02
            // 
            this.screen02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.screen02.Controls.Add(this.label42);
            this.screen02.Controls.Add(this.button75);
            this.screen02.Controls.Add(this.screen4);
            this.screen02.Controls.Add(this.button76);
            this.screen02.Controls.Add(this.button77);
            this.screen02.Controls.Add(this.button78);
            this.screen02.Controls.Add(this.button79);
            this.screen02.Controls.Add(this.button80);
            this.screen02.Controls.Add(this.panel10);
            this.screen02.Location = new System.Drawing.Point(0, 0);
            this.screen02.Name = "screen02";
            this.screen02.Size = new System.Drawing.Size(548, 290);
            this.screen02.TabIndex = 56;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Transparent;
            this.label42.Location = new System.Drawing.Point(232, 14);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(87, 24);
            this.label42.TabIndex = 20;
            this.label42.Text = "Transfer";
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.DarkGray;
            this.button75.Image = ((System.Drawing.Image)(resources.GetObject("button75.Image")));
            this.button75.Location = new System.Drawing.Point(0, 50);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(108, 56);
            this.button75.TabIndex = 19;
            this.button75.Text = "  ";
            this.button75.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.Silver;
            this.button76.Image = ((System.Drawing.Image)(resources.GetObject("button76.Image")));
            this.button76.Location = new System.Drawing.Point(0, 122);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(108, 56);
            this.button76.TabIndex = 14;
            this.button76.Text = "  ";
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.Silver;
            this.button77.Image = ((System.Drawing.Image)(resources.GetObject("button77.Image")));
            this.button77.Location = new System.Drawing.Point(0, 197);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(108, 56);
            this.button77.TabIndex = 15;
            this.button77.Text = "  ";
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.Silver;
            this.button78.Image = ((System.Drawing.Image)(resources.GetObject("button78.Image")));
            this.button78.Location = new System.Drawing.Point(428, 50);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(108, 56);
            this.button78.TabIndex = 16;
            this.button78.Text = " ";
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.Silver;
            this.button79.Image = ((System.Drawing.Image)(resources.GetObject("button79.Image")));
            this.button79.Location = new System.Drawing.Point(428, 122);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(108, 56);
            this.button79.TabIndex = 17;
            this.button79.Text = " ";
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.Silver;
            this.button80.Image = ((System.Drawing.Image)(resources.GetObject("button80.Image")));
            this.button80.Location = new System.Drawing.Point(428, 197);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(108, 56);
            this.button80.TabIndex = 18;
            this.button80.Text = " ";
            this.button80.UseVisualStyleBackColor = false;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.label43);
            this.panel10.Controls.Add(this.label44);
            this.panel10.Controls.Add(this.textBox3);
            this.panel10.Location = new System.Drawing.Point(115, 50);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(306, 213);
            this.panel10.TabIndex = 0;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(197, 171);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(69, 18);
            this.label43.TabIndex = 2;
            this.label43.Text = "process";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(56, 72);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(95, 20);
            this.label44.TabIndex = 1;
            this.label44.Text = "OTP Code";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(33, 106);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(237, 22);
            this.textBox3.TabIndex = 0;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Silver;
            this.button16.Image = ((System.Drawing.Image)(resources.GetObject("button16.Image")));
            this.button16.Location = new System.Drawing.Point(428, 50);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(108, 56);
            this.button16.TabIndex = 16;
            this.button16.Text = " ";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Silver;
            this.button17.Image = ((System.Drawing.Image)(resources.GetObject("button17.Image")));
            this.button17.Location = new System.Drawing.Point(428, 122);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(108, 56);
            this.button17.TabIndex = 17;
            this.button17.Text = " ";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Silver;
            this.button18.Image = ((System.Drawing.Image)(resources.GetObject("button18.Image")));
            this.button18.Location = new System.Drawing.Point(428, 197);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(108, 56);
            this.button18.TabIndex = 18;
            this.button18.Text = " ";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.invalid);
            this.panel2.Controls.Add(this.textbox1);
            this.panel2.Location = new System.Drawing.Point(115, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(306, 213);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(198, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "process";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(105, 55);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 17);
            this.label12.TabIndex = 2;
            this.label12.Text = "Input PIN";
            // 
            // invalid
            // 
            this.invalid.AutoSize = true;
            this.invalid.Location = new System.Drawing.Point(118, 132);
            this.invalid.Name = "invalid";
            this.invalid.Size = new System.Drawing.Size(0, 17);
            this.invalid.TabIndex = 1;
            // 
            // textbox1
            // 
            this.textbox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox1.Location = new System.Drawing.Point(48, 92);
            this.textbox1.Name = "textbox1";
            this.textbox1.PasswordChar = '$';
            this.textbox1.Size = new System.Drawing.Size(213, 28);
            this.textbox1.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(117, 330);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(548, 414);
            this.panel1.TabIndex = 55;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.DarkGray;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(153, 344);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(108, 56);
            this.button10.TabIndex = 20;
            this.button10.Text = "0";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.ForestGreen;
            this.button13.Location = new System.Drawing.Point(436, 246);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(108, 56);
            this.button13.TabIndex = 19;
            this.button13.Text = "button13";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Red;
            this.button12.Location = new System.Drawing.Point(436, 139);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(108, 56);
            this.button12.TabIndex = 18;
            this.button12.Text = "button12";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Gold;
            this.button11.Location = new System.Drawing.Point(436, 34);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(108, 56);
            this.button11.TabIndex = 17;
            this.button11.Text = "button11";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkGray;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(290, 130);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(108, 63);
            this.button4.TabIndex = 16;
            this.button4.Text = "6";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkGray;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(290, 28);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 57);
            this.button3.TabIndex = 15;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.DarkGray;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(290, 246);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(108, 56);
            this.button9.TabIndex = 14;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkGray;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(3, 246);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(101, 56);
            this.button8.TabIndex = 13;
            this.button8.Text = "7";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkGray;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(153, 246);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(105, 56);
            this.button7.TabIndex = 12;
            this.button7.Text = "8";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DarkGray;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(7, 130);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(101, 63);
            this.button6.TabIndex = 11;
            this.button6.Text = "4";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkGray;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(153, 130);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(105, 63);
            this.button5.TabIndex = 10;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkGray;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(153, 28);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 57);
            this.button2.TabIndex = 9;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(3, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 57);
            this.button1.TabIndex = 8;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // screen4
            // 
            this.screen4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.screen4.Controls.Add(this.label5);
            this.screen4.Controls.Add(this.button26);
            this.screen4.Controls.Add(this.button27);
            this.screen4.Controls.Add(this.button28);
            this.screen4.Controls.Add(this.button29);
            this.screen4.Controls.Add(this.button30);
            this.screen4.Controls.Add(this.button31);
            this.screen4.Controls.Add(this.panel5);
            this.screen4.Location = new System.Drawing.Point(0, 0);
            this.screen4.Name = "screen4";
            this.screen4.Size = new System.Drawing.Size(548, 290);
            this.screen4.TabIndex = 58;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(232, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 24);
            this.label5.TabIndex = 20;
            this.label5.Text = "ATM";
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.DarkGray;
            this.button26.Image = ((System.Drawing.Image)(resources.GetObject("button26.Image")));
            this.button26.Location = new System.Drawing.Point(0, 50);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(108, 56);
            this.button26.TabIndex = 19;
            this.button26.Text = "  ";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Silver;
            this.button27.Image = ((System.Drawing.Image)(resources.GetObject("button27.Image")));
            this.button27.Location = new System.Drawing.Point(0, 122);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(108, 56);
            this.button27.TabIndex = 14;
            this.button27.Text = "  ";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Silver;
            this.button28.Image = ((System.Drawing.Image)(resources.GetObject("button28.Image")));
            this.button28.Location = new System.Drawing.Point(0, 197);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(108, 56);
            this.button28.TabIndex = 15;
            this.button28.Text = "  ";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Silver;
            this.button29.Image = ((System.Drawing.Image)(resources.GetObject("button29.Image")));
            this.button29.Location = new System.Drawing.Point(428, 51);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(108, 56);
            this.button29.TabIndex = 16;
            this.button29.Text = " ";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Silver;
            this.button30.Image = ((System.Drawing.Image)(resources.GetObject("button30.Image")));
            this.button30.Location = new System.Drawing.Point(428, 122);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(108, 56);
            this.button30.TabIndex = 17;
            this.button30.Text = " ";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Silver;
            this.button31.Image = ((System.Drawing.Image)(resources.GetObject("button31.Image")));
            this.button31.Location = new System.Drawing.Point(428, 197);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(108, 56);
            this.button31.TabIndex = 18;
            this.button31.Text = " ";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.label14);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.label19);
            this.panel5.Location = new System.Drawing.Point(115, 50);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(306, 213);
            this.panel5.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 101);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 20);
            this.label14.TabIndex = 11;
            this.label14.Text = "loan";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(208, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 20);
            this.label15.TabIndex = 10;
            this.label15.Text = "Balance";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(212, 170);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 20);
            this.label16.TabIndex = 9;
            this.label16.Text = "AirTime";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(12, 170);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 20);
            this.label17.TabIndex = 8;
            this.label17.Text = "Transfar";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(216, 101);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 20);
            this.label18.TabIndex = 7;
            this.label18.Text = "deposit";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 23);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(98, 20);
            this.label19.TabIndex = 6;
            this.label19.Text = "withdrawal";
            // 
            // screen1
            // 
            this.screen1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.screen1.Controls.Add(this.label2);
            this.screen1.Controls.Add(this.button20);
            this.screen1.Controls.Add(this.button21);
            this.screen1.Controls.Add(this.button22);
            this.screen1.Controls.Add(this.button23);
            this.screen1.Controls.Add(this.button24);
            this.screen1.Controls.Add(this.button25);
            this.screen1.Controls.Add(this.panel4);
            this.screen1.Location = new System.Drawing.Point(117, 21);
            this.screen1.Name = "screen1";
            this.screen1.Size = new System.Drawing.Size(548, 290);
            this.screen1.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(232, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 24);
            this.label2.TabIndex = 20;
            this.label2.Text = "ATM";
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.DarkGray;
            this.button20.Image = ((System.Drawing.Image)(resources.GetObject("button20.Image")));
            this.button20.Location = new System.Drawing.Point(0, 50);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(108, 56);
            this.button20.TabIndex = 19;
            this.button20.Text = " ";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Silver;
            this.button21.Image = ((System.Drawing.Image)(resources.GetObject("button21.Image")));
            this.button21.Location = new System.Drawing.Point(0, 122);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(108, 56);
            this.button21.TabIndex = 14;
            this.button21.Text = " ";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Silver;
            this.button22.Image = ((System.Drawing.Image)(resources.GetObject("button22.Image")));
            this.button22.Location = new System.Drawing.Point(0, 197);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(108, 56);
            this.button22.TabIndex = 15;
            this.button22.Text = " ";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Silver;
            this.button23.Image = ((System.Drawing.Image)(resources.GetObject("button23.Image")));
            this.button23.Location = new System.Drawing.Point(428, 50);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(108, 56);
            this.button23.TabIndex = 16;
            this.button23.Text = " ";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Silver;
            this.button24.Image = ((System.Drawing.Image)(resources.GetObject("button24.Image")));
            this.button24.Location = new System.Drawing.Point(428, 122);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(108, 56);
            this.button24.TabIndex = 17;
            this.button24.Text = " ";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Silver;
            this.button25.Image = ((System.Drawing.Image)(resources.GetObject("button25.Image")));
            this.button25.Location = new System.Drawing.Point(428, 197);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(108, 56);
            this.button25.TabIndex = 18;
            this.button25.Text = " ";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Location = new System.Drawing.Point(115, 50);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(306, 213);
            this.panel4.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(198, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "next";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(118, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 17);
            this.label6.TabIndex = 1;
            // 
            // another
            // 
            this.another.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.another.Controls.Add(this.ascreen1);
            this.another.Controls.Add(this.label7);
            this.another.Controls.Add(this.wscreen1);
            this.another.Controls.Add(this.button32);
            this.another.Controls.Add(this.button33);
            this.another.Controls.Add(this.button34);
            this.another.Controls.Add(this.button35);
            this.another.Controls.Add(this.button36);
            this.another.Controls.Add(this.button37);
            this.another.Controls.Add(this.panel6);
            this.another.Location = new System.Drawing.Point(734, 24);
            this.another.Name = "another";
            this.another.Size = new System.Drawing.Size(548, 290);
            this.another.TabIndex = 59;
            // 
            // ascreen1
            // 
            this.ascreen1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.ascreen1.Controls.Add(this.label27);
            this.ascreen1.Controls.Add(this.button38);
            this.ascreen1.Controls.Add(this.button45);
            this.ascreen1.Controls.Add(this.button46);
            this.ascreen1.Controls.Add(this.button47);
            this.ascreen1.Controls.Add(this.button48);
            this.ascreen1.Controls.Add(this.button49);
            this.ascreen1.Controls.Add(this.panel8);
            this.ascreen1.Location = new System.Drawing.Point(3, 11);
            this.ascreen1.Name = "ascreen1";
            this.ascreen1.Size = new System.Drawing.Size(548, 290);
            this.ascreen1.TabIndex = 61;
            this.ascreen1.Paint += new System.Windows.Forms.PaintEventHandler(this.ascreen1_Paint);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Transparent;
            this.label27.Location = new System.Drawing.Point(232, 14);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(117, 24);
            this.label27.TabIndex = 20;
            this.label27.Text = "Withdeawal";
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.DarkGray;
            this.button38.Image = ((System.Drawing.Image)(resources.GetObject("button38.Image")));
            this.button38.Location = new System.Drawing.Point(0, 50);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(108, 56);
            this.button38.TabIndex = 19;
            this.button38.Text = "  ";
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Silver;
            this.button45.Image = ((System.Drawing.Image)(resources.GetObject("button45.Image")));
            this.button45.Location = new System.Drawing.Point(0, 122);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(108, 56);
            this.button45.TabIndex = 14;
            this.button45.Text = "  ";
            this.button45.UseVisualStyleBackColor = false;
            // 
            // screen5
            // 
            this.screen5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.screen5.Controls.Add(this.label30);
            this.screen5.Controls.Add(this.button50);
            this.screen5.Controls.Add(this.button51);
            this.screen5.Controls.Add(this.button52);
            this.screen5.Controls.Add(this.button53);
            this.screen5.Controls.Add(this.button54);
            this.screen5.Controls.Add(this.button55);
            this.screen5.Controls.Add(this.panel9);
            this.screen5.Location = new System.Drawing.Point(1336, 388);
            this.screen5.Name = "screen5";
            this.screen5.Size = new System.Drawing.Size(548, 290);
            this.screen5.TabIndex = 60;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Transparent;
            this.label30.Location = new System.Drawing.Point(232, 14);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(54, 24);
            this.label30.TabIndex = 20;
            this.label30.Text = "ATM";
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.DarkGray;
            this.button50.Image = ((System.Drawing.Image)(resources.GetObject("button50.Image")));
            this.button50.Location = new System.Drawing.Point(0, 50);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(108, 56);
            this.button50.TabIndex = 19;
            this.button50.Text = "  ";
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.Silver;
            this.button51.Image = ((System.Drawing.Image)(resources.GetObject("button51.Image")));
            this.button51.Location = new System.Drawing.Point(0, 122);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(108, 56);
            this.button51.TabIndex = 14;
            this.button51.Text = "  ";
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Silver;
            this.button52.Image = ((System.Drawing.Image)(resources.GetObject("button52.Image")));
            this.button52.Location = new System.Drawing.Point(0, 197);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(108, 56);
            this.button52.TabIndex = 15;
            this.button52.Text = "  ";
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.Silver;
            this.button53.Image = ((System.Drawing.Image)(resources.GetObject("button53.Image")));
            this.button53.Location = new System.Drawing.Point(428, 51);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(108, 56);
            this.button53.TabIndex = 16;
            this.button53.Text = " ";
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.Silver;
            this.button54.Image = ((System.Drawing.Image)(resources.GetObject("button54.Image")));
            this.button54.Location = new System.Drawing.Point(428, 122);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(108, 56);
            this.button54.TabIndex = 17;
            this.button54.Text = " ";
            this.button54.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.Silver;
            this.button55.Image = ((System.Drawing.Image)(resources.GetObject("button55.Image")));
            this.button55.Location = new System.Drawing.Point(428, 197);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(108, 56);
            this.button55.TabIndex = 18;
            this.button55.Text = " ";
            this.button55.UseVisualStyleBackColor = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Controls.Add(this.label38);
            this.panel9.Controls.Add(this.label33);
            this.panel9.Controls.Add(this.label34);
            this.panel9.Controls.Add(this.label35);
            this.panel9.Controls.Add(this.label36);
            this.panel9.Controls.Add(this.label37);
            this.panel9.Location = new System.Drawing.Point(115, 50);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(306, 213);
            this.panel9.TabIndex = 0;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(12, 167);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(64, 17);
            this.label38.TabIndex = 17;
            this.label38.Text = "ZENITH";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(12, 27);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(68, 17);
            this.label33.TabIndex = 16;
            this.label33.Text = "ACCESS";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(225, 169);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(74, 17);
            this.label34.TabIndex = 15;
            this.label34.Text = "POLARIS";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(253, 92);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(40, 17);
            this.label35.TabIndex = 14;
            this.label35.Text = "ECO";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(12, 98);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(52, 17);
            this.label36.TabIndex = 13;
            this.label36.Text = "FIRST";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(263, 20);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 17);
            this.label37.TabIndex = 12;
            this.label37.Text = "GT";
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Silver;
            this.button46.Image = ((System.Drawing.Image)(resources.GetObject("button46.Image")));
            this.button46.Location = new System.Drawing.Point(0, 197);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(108, 56);
            this.button46.TabIndex = 15;
            this.button46.Text = "  ";
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Silver;
            this.button47.Image = ((System.Drawing.Image)(resources.GetObject("button47.Image")));
            this.button47.Location = new System.Drawing.Point(428, 50);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(108, 56);
            this.button47.TabIndex = 16;
            this.button47.Text = " ";
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Silver;
            this.button48.Image = ((System.Drawing.Image)(resources.GetObject("button48.Image")));
            this.button48.Location = new System.Drawing.Point(428, 122);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(108, 56);
            this.button48.TabIndex = 17;
            this.button48.Text = " ";
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Silver;
            this.button49.Image = ((System.Drawing.Image)(resources.GetObject("button49.Image")));
            this.button49.Location = new System.Drawing.Point(428, 198);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(108, 56);
            this.button49.TabIndex = 18;
            this.button49.Text = " ";
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.label29);
            this.panel8.Controls.Add(this.label28);
            this.panel8.Controls.Add(this.textBox2);
            this.panel8.Location = new System.Drawing.Point(115, 50);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(306, 213);
            this.panel8.TabIndex = 0;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(217, 165);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(76, 20);
            this.label29.TabIndex = 5;
            this.label29.Text = "process";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(74, 64);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(82, 20);
            this.label28.TabIndex = 1;
            this.label28.Text = "AIRTIME";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(29, 89);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(242, 22);
            this.textBox2.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(232, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 24);
            this.label7.TabIndex = 20;
            this.label7.Text = "Transfer";
            // 
            // wscreen1
            // 
            this.wscreen1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.wscreen1.Controls.Add(this.label20);
            this.wscreen1.Controls.Add(this.button39);
            this.wscreen1.Controls.Add(this.button40);
            this.wscreen1.Controls.Add(this.button41);
            this.wscreen1.Controls.Add(this.button42);
            this.wscreen1.Controls.Add(this.button43);
            this.wscreen1.Controls.Add(this.button44);
            this.wscreen1.Controls.Add(this.panel3);
            this.wscreen1.Location = new System.Drawing.Point(3, 14);
            this.wscreen1.Name = "wscreen1";
            this.wscreen1.Size = new System.Drawing.Size(548, 290);
            this.wscreen1.TabIndex = 60;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Transparent;
            this.label20.Location = new System.Drawing.Point(232, 14);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(117, 24);
            this.label20.TabIndex = 20;
            this.label20.Text = "Withdeawal";
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.DarkGray;
            this.button39.Image = ((System.Drawing.Image)(resources.GetObject("button39.Image")));
            this.button39.Location = new System.Drawing.Point(0, 50);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(108, 56);
            this.button39.TabIndex = 19;
            this.button39.Text = "  ";
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Silver;
            this.button40.Image = ((System.Drawing.Image)(resources.GetObject("button40.Image")));
            this.button40.Location = new System.Drawing.Point(0, 122);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(108, 56);
            this.button40.TabIndex = 14;
            this.button40.Text = "  ";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.Silver;
            this.button41.Image = ((System.Drawing.Image)(resources.GetObject("button41.Image")));
            this.button41.Location = new System.Drawing.Point(0, 197);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(108, 56);
            this.button41.TabIndex = 15;
            this.button41.Text = "  ";
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.Silver;
            this.button42.Image = ((System.Drawing.Image)(resources.GetObject("button42.Image")));
            this.button42.Location = new System.Drawing.Point(428, 50);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(108, 56);
            this.button42.TabIndex = 16;
            this.button42.Text = " ";
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.Silver;
            this.button43.Image = ((System.Drawing.Image)(resources.GetObject("button43.Image")));
            this.button43.Location = new System.Drawing.Point(428, 122);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(108, 56);
            this.button43.TabIndex = 17;
            this.button43.Text = " ";
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Silver;
            this.button44.Image = ((System.Drawing.Image)(resources.GetObject("button44.Image")));
            this.button44.Location = new System.Drawing.Point(428, 198);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(108, 56);
            this.button44.TabIndex = 18;
            this.button44.Text = " ";
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Location = new System.Drawing.Point(115, 50);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(306, 213);
            this.panel3.TabIndex = 0;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(16, 98);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 20);
            this.label21.TabIndex = 5;
            this.label21.Text = "1000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(226, 24);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(49, 20);
            this.label22.TabIndex = 4;
            this.label22.Text = "5000";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(215, 167);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 20);
            this.label23.TabIndex = 3;
            this.label23.Text = "20000";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(16, 167);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(49, 20);
            this.label24.TabIndex = 2;
            this.label24.Text = "2000";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(219, 98);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 20);
            this.label25.TabIndex = 1;
            this.label25.Text = "10000";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(16, 20);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(39, 20);
            this.label26.TabIndex = 0;
            this.label26.Text = "500";
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.DarkGray;
            this.button32.Image = ((System.Drawing.Image)(resources.GetObject("button32.Image")));
            this.button32.Location = new System.Drawing.Point(0, 50);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(108, 56);
            this.button32.TabIndex = 19;
            this.button32.Text = "  ";
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Silver;
            this.button33.Image = ((System.Drawing.Image)(resources.GetObject("button33.Image")));
            this.button33.Location = new System.Drawing.Point(0, 122);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(108, 56);
            this.button33.TabIndex = 14;
            this.button33.Text = "  ";
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Silver;
            this.button34.Image = ((System.Drawing.Image)(resources.GetObject("button34.Image")));
            this.button34.Location = new System.Drawing.Point(0, 197);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(108, 56);
            this.button34.TabIndex = 15;
            this.button34.Text = "  ";
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Silver;
            this.button35.Image = ((System.Drawing.Image)(resources.GetObject("button35.Image")));
            this.button35.Location = new System.Drawing.Point(428, 50);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(108, 56);
            this.button35.TabIndex = 16;
            this.button35.Text = " ";
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Silver;
            this.button36.Image = ((System.Drawing.Image)(resources.GetObject("button36.Image")));
            this.button36.Location = new System.Drawing.Point(428, 122);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(108, 56);
            this.button36.TabIndex = 17;
            this.button36.Text = " ";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.Silver;
            this.button37.Image = ((System.Drawing.Image)(resources.GetObject("button37.Image")));
            this.button37.Location = new System.Drawing.Point(428, 197);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(108, 56);
            this.button37.TabIndex = 18;
            this.button37.Text = " ";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Location = new System.Drawing.Point(115, 50);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(306, 213);
            this.panel6.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(255, 166);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 18);
            this.label13.TabIndex = 4;
            this.label13.Text = "YES";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Mongolian Baiti", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(264, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 18);
            this.label11.TabIndex = 3;
            this.label11.Text = "NO";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(50, 145);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(150, 17);
            this.label10.TabIndex = 2;
            this.label10.Text = "Anothe Transaction";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(60, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 17);
            this.label9.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(118, 106);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 0;
            // 
            // Tscreen2
            // 
            this.Tscreen2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.Tscreen2.Controls.Add(this.label31);
            this.Tscreen2.Controls.Add(this.button56);
            this.Tscreen2.Controls.Add(this.button57);
            this.Tscreen2.Controls.Add(this.button58);
            this.Tscreen2.Controls.Add(this.button59);
            this.Tscreen2.Controls.Add(this.button60);
            this.Tscreen2.Controls.Add(this.button61);
            this.Tscreen2.Controls.Add(this.panel11);
            this.Tscreen2.Location = new System.Drawing.Point(753, 401);
            this.Tscreen2.Name = "Tscreen2";
            this.Tscreen2.Size = new System.Drawing.Size(548, 290);
            this.Tscreen2.TabIndex = 62;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Transparent;
            this.label31.Location = new System.Drawing.Point(232, 14);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(87, 24);
            this.label31.TabIndex = 20;
            this.label31.Text = "Transfer";
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.DarkGray;
            this.button56.Image = ((System.Drawing.Image)(resources.GetObject("button56.Image")));
            this.button56.Location = new System.Drawing.Point(0, 50);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(108, 56);
            this.button56.TabIndex = 19;
            this.button56.Text = "  ";
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.Silver;
            this.button57.Image = ((System.Drawing.Image)(resources.GetObject("button57.Image")));
            this.button57.Location = new System.Drawing.Point(0, 122);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(108, 56);
            this.button57.TabIndex = 14;
            this.button57.Text = "  ";
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.Silver;
            this.button58.Image = ((System.Drawing.Image)(resources.GetObject("button58.Image")));
            this.button58.Location = new System.Drawing.Point(0, 197);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(108, 56);
            this.button58.TabIndex = 15;
            this.button58.Text = "  ";
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.Silver;
            this.button59.Image = ((System.Drawing.Image)(resources.GetObject("button59.Image")));
            this.button59.Location = new System.Drawing.Point(428, 50);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(108, 56);
            this.button59.TabIndex = 16;
            this.button59.Text = " ";
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Silver;
            this.button60.Image = ((System.Drawing.Image)(resources.GetObject("button60.Image")));
            this.button60.Location = new System.Drawing.Point(428, 122);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(108, 56);
            this.button60.TabIndex = 17;
            this.button60.Text = " ";
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.Silver;
            this.button61.Image = ((System.Drawing.Image)(resources.GetObject("button61.Image")));
            this.button61.Location = new System.Drawing.Point(428, 198);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(108, 56);
            this.button61.TabIndex = 18;
            this.button61.Text = " ";
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Controls.Add(this.label47);
            this.panel11.Controls.Add(this.label46);
            this.panel11.Controls.Add(this.label32);
            this.panel11.Controls.Add(this.label39);
            this.panel11.Controls.Add(this.textBox4);
            this.panel11.Location = new System.Drawing.Point(115, 50);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(306, 213);
            this.panel11.TabIndex = 0;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(89, 8);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(0, 17);
            this.label47.TabIndex = 7;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(26, 20);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(0, 17);
            this.label46.TabIndex = 6;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(217, 165);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(76, 20);
            this.label32.TabIndex = 5;
            this.label32.Text = "process";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(74, 64);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(62, 17);
            this.label39.TabIndex = 1;
            this.label39.Text = "Amount";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(29, 89);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(242, 22);
            this.textBox4.TabIndex = 0;
            // 
            // Tscreen1
            // 
            this.Tscreen1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.Tscreen1.Controls.Add(this.label40);
            this.Tscreen1.Controls.Add(this.button62);
            this.Tscreen1.Controls.Add(this.button63);
            this.Tscreen1.Controls.Add(this.button64);
            this.Tscreen1.Controls.Add(this.button65);
            this.Tscreen1.Controls.Add(this.button66);
            this.Tscreen1.Controls.Add(this.button67);
            this.Tscreen1.Controls.Add(this.panel12);
            this.Tscreen1.Location = new System.Drawing.Point(1300, 38);
            this.Tscreen1.Name = "Tscreen1";
            this.Tscreen1.Size = new System.Drawing.Size(548, 290);
            this.Tscreen1.TabIndex = 63;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Transparent;
            this.label40.Location = new System.Drawing.Point(232, 14);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(87, 24);
            this.label40.TabIndex = 20;
            this.label40.Text = "Transfer";
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.DarkGray;
            this.button62.Image = ((System.Drawing.Image)(resources.GetObject("button62.Image")));
            this.button62.Location = new System.Drawing.Point(0, 50);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(108, 56);
            this.button62.TabIndex = 19;
            this.button62.Text = "  ";
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Silver;
            this.button63.Image = ((System.Drawing.Image)(resources.GetObject("button63.Image")));
            this.button63.Location = new System.Drawing.Point(0, 122);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(108, 56);
            this.button63.TabIndex = 14;
            this.button63.Text = "  ";
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.Silver;
            this.button64.Image = ((System.Drawing.Image)(resources.GetObject("button64.Image")));
            this.button64.Location = new System.Drawing.Point(0, 197);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(108, 56);
            this.button64.TabIndex = 15;
            this.button64.Text = "  ";
            this.button64.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.Silver;
            this.button65.Image = ((System.Drawing.Image)(resources.GetObject("button65.Image")));
            this.button65.Location = new System.Drawing.Point(428, 50);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(108, 56);
            this.button65.TabIndex = 16;
            this.button65.Text = " ";
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.Silver;
            this.button66.Image = ((System.Drawing.Image)(resources.GetObject("button66.Image")));
            this.button66.Location = new System.Drawing.Point(428, 122);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(108, 56);
            this.button66.TabIndex = 17;
            this.button66.Text = " ";
            this.button66.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.Silver;
            this.button67.Image = ((System.Drawing.Image)(resources.GetObject("button67.Image")));
            this.button67.Location = new System.Drawing.Point(428, 198);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(108, 56);
            this.button67.TabIndex = 18;
            this.button67.Text = " ";
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.label41);
            this.panel12.Controls.Add(this.label45);
            this.panel12.Controls.Add(this.textBox5);
            this.panel12.Location = new System.Drawing.Point(115, 50);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(306, 213);
            this.panel12.TabIndex = 0;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(217, 165);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(76, 20);
            this.label41.TabIndex = 5;
            this.label41.Text = "process";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(36, 66);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(149, 20);
            this.label45.TabIndex = 1;
            this.label45.Text = " Amount Number";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(29, 89);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(242, 22);
            this.textBox5.TabIndex = 0;
            // 
            // ATM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(50)))), ((int)(((byte)(67)))));
            this.ClientSize = new System.Drawing.Size(1924, 791);
            this.Controls.Add(this.Tscreen2);
            this.Controls.Add(this.Tscreen1);
            this.Controls.Add(this.screen5);
            this.Controls.Add(this.another);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.SCREEN2);
            this.Controls.Add(this.screen1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "ATM";
            this.Text = "ATM";
            this.Load += new System.EventHandler(this.ATM_Load);
            this.SCREEN2.ResumeLayout(false);
            this.SCREEN2.PerformLayout();
            this.screen02.ResumeLayout(false);
            this.screen02.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.screen4.ResumeLayout(false);
            this.screen4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.screen1.ResumeLayout(false);
            this.screen1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.another.ResumeLayout(false);
            this.another.PerformLayout();
            this.ascreen1.ResumeLayout(false);
            this.ascreen1.PerformLayout();
            this.screen5.ResumeLayout(false);
            this.screen5.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.wscreen1.ResumeLayout(false);
            this.wscreen1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.Tscreen2.ResumeLayout(false);
            this.Tscreen2.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.Tscreen1.ResumeLayout(false);
            this.Tscreen1.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel SCREEN2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label invalid;
        private System.Windows.Forms.TextBox textbox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel screen02;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel screen1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel screen4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel another;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel wscreen1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel ascreen1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel screen5;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel Tscreen2;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Panel Tscreen1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
    }
}