﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace new_Project
{
    public partial class Form2 : Form
    {
        MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        String bankname;
        String Gender;
        public Form2()
        {
            InitializeComponent();
        }

        private void Submit_Click(object sender, EventArgs e)
        {

            string insertQuery = "INSERT INTO atm."+bankname+"(FirstName,lastname,address,occupation,phonenumber,pin,accountnumber,email,accountbalance) VALUES('" + textBox1.Text + "','" + textBox11.Text + "','" + textBox12.Text + "','" + textBox13.Text + "','" + textBox14.Text + "','" + textBox15.Text + "','" + textBox16.Text + "','" + textBox17.Text + "','" + textBox18.Text + "')";
            connection.Open();


            MySqlCommand command = new MySqlCommand(insertQuery, connection);

            try
            {
                if (command.ExecuteNonQuery() == 1)
                {

                    MessageBox.Show("Data inserted");
                    new Form1().Show();
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("data not inserted");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            bankname = "access";
        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            bankname = "uba";

        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            bankname = "zenith";

        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            bankname = "polaris";
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            bankname = "first";
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            bankname = "wema";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }
    }
}
