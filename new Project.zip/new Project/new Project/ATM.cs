﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace new_Project
{
    public partial class ATM : Form
    {

        MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        string accountb;
        string recharge;
        string bankname;
        string Tamount;
        public ATM()
        {
            InitializeComponent();
        }

        private void ATM_Load(object sender, EventArgs e)
        {
            string bankname;
            screen02.Visible = false;
            SCREEN2.Visible = false;
            ascreen1.Visible = false;
            wscreen1.Visible = false;
            screen4.Visible = false;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            //pin

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                screen02.Visible = true;
                textBox3.Text = "";

            }
            else
            {
                MessageBox.Show("NO");
            }



        }

        private void button25_Click(object sender, EventArgs e)
        {
            // screen one 
            SCREEN2.Visible = true;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            textbox1.Text = "";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("confirm you want to exit ", "ATM system", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "3";
            textBox3.Text = textBox3.Text + "3";
            textBox2.Text = textBox2.Text + "3";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "2";
            textBox3.Text = textBox3.Text + "2";
            textBox2.Text = textBox2.Text + "2";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "1";
            textBox3.Text = textBox3.Text + "1";
            textBox2.Text = textBox2.Text + "1";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "4";
            textBox3.Text = textBox3.Text + "4";
            textBox2.Text = textBox2.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "5";
            textBox3.Text = textBox3.Text + "5";
            textBox2.Text = textBox2.Text + "5";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "6";
            textBox3.Text = textBox3.Text + "6";
            textBox2.Text = textBox2.Text + "6";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "7";
            textBox3.Text = textBox3.Text + "7";
            textBox2.Text = textBox2.Text + "7";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "8";
            textBox3.Text = textBox3.Text + "8";
            textBox2.Text = textBox2.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "9";
            textBox3.Text = textBox3.Text + "9";
            textBox2.Text = textBox2.Text + "9";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textbox1.Text = textbox1.Text + "0";
            textBox3.Text = textBox3.Text + "0";
            textBox2.Text = textBox2.Text + "0";
        }

        private void button80_Click(object sender, EventArgs e)
        {
            // OTP
            screen4.Visible = true;
        }

        private void button29_Click(object sender, EventArgs e)
        {
            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
           
            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            another.Visible = true;
            accountb = acctBalance;
            label8.Text = accountb;
            label9.Text = "Your account Balance is ";

        }

        private void button36_Click(object sender, EventArgs e)
        {

            DialogResult iExit;
            iExit = MessageBox.Show("confirm you want to exit ", "ATM system", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            screen1.Visible = true;
            SCREEN2.Visible = false;
            screen4.Visible = false;
            another.Visible = false;
            screen02.Visible = false;
        }

        private void button26_Click(object sender, EventArgs e)
        {
            screen1.Visible = false;
            SCREEN2.Visible = false;
            screen4.Visible = false;
            another.Visible = false;
            screen02.Visible = false;
            wscreen1.Visible = true;
        }

        private void button39_Click(object sender, EventArgs e)
        {
            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal = int.Parse(acctBalance);
            if (bal > 500)
            {
                int newAmount = bal - 500;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update = "UPDATE atm.access SET accountbalance='" + newAmount + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("sucess  = ", newAmount.ToString());
                        another.Visible = true;
                        label9.Text = "SUCCESSFUL";
                    }
                    else
                        MessageBox.Show("fail  = ", newAmount.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }



            }
        }

        private void button42_Click(object sender, EventArgs e)
        {

            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal = int.Parse(acctBalance);
            if (bal > 5000)
            {
                int newAmount = bal - 5000;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update = "UPDATE atm.access SET accountbalance='" + newAmount + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                        MessageBox.Show("sucess  = ", newAmount.ToString());
                    else
                        MessageBox.Show("fail  = ", newAmount.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
        }

        private void button40_Click(object sender, EventArgs e)
        {

            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal = int.Parse(acctBalance);
            if (bal > 1000)
            {
                int newAmount = bal - 1000;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update = "UPDATE atm.access SET accountbalance='" + newAmount + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                        MessageBox.Show("sucess  = ", newAmount.ToString());
                    else
                        MessageBox.Show("fail  = ", newAmount.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
        }

        private void button43_Click(object sender, EventArgs e)
        {

            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal = int.Parse(acctBalance);
            if (bal > 10000)
            {
                int newAmount = bal - 10000;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update = "UPDATE atm.access SET accountbalance='" + newAmount + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                        MessageBox.Show("sucess  = ", newAmount.ToString());
                    else
                        MessageBox.Show("fail  = ", newAmount.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
        }

        private void button41_Click(object sender, EventArgs e)
        {

            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal = int.Parse(acctBalance);
            if (bal > 2000)
            {
                int newAmount = bal - 2000;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update = "UPDATE atm.access SET accountbalance='" + newAmount + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                        MessageBox.Show("sucess  = ", newAmount.ToString());
                    else
                        MessageBox.Show("fail  = ", newAmount.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
        }

        private void button44_Click(object sender, EventArgs e)
        {

            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal = int.Parse(acctBalance);
            if (bal > 20000)
            {
                int newAmount = bal - 20000;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update = "UPDATE atm.access SET accountbalance='" + newAmount + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                        MessageBox.Show("sucess  = ", newAmount.ToString());
                    else
                        MessageBox.Show("fail  = ", newAmount.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }

            }
        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void button49_Click(object sender, EventArgs e)
        {
            // airtime
            recharge = textBox2.Text;
            MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal2 = int.Parse(acctBalance);
            int withdraw = int.Parse(recharge);
            if (bal2 > withdraw)
            {
                int rech = bal2 - withdraw;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update = "UPDATE atm.access SET accountbalance='" + rech + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("sucess  = ", rech.ToString());
                        another.Visible = true;
                        label9.Text = "SUCCESSFUL";
                    }
                    else
                        MessageBox.Show("fail  = ", rech.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }




            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            ascreen1.Visible = true;
        }

        private void ascreen1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button67_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            connection.Open();
            String select = "Select * from atm.access where accountnumber ='" + int.Parse(textBox5.Text) + "'";
            MySqlCommand cmmd = new MySqlCommand(select, connection);
            MySqlDataReader dr = cmmd.ExecuteReader();
            if (dr . Read())
            {
                Tscreen2.Visible = true;
                label46.Text = (dr["lastname"].ToString() + " "+ dr["FirstName"].ToString());
               // label47.Text = (dr["FirstName"].ToString());
            }
            else
            {
                MessageBox.Show("account dont exist");
            }
            
         


        }
        private void button28_Click(object sender, EventArgs e)
        {
            screen5.Visible = true;
            Tscreen1.Visible = false;
        }

        private void button50_Click(object sender, EventArgs e)
        {
            Tscreen1.Visible = true;
        }

        private void button61_Click(object sender, EventArgs e)
        {
            Tamount = textBox4.Text;
            //MySqlDataReader mdr = null;

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            String query = "Select * from atm.access where pin ='" + textbox1.Text + "'";
            MySqlDataAdapter sda = new MySqlDataAdapter(query, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            String acctBalance = null;

            if (dt.Rows.Count == 1)
            {
                acctBalance = dt.Rows[0]["accountbalance"].ToString();
            }
            int bal3 = int.Parse(acctBalance);
            int withdraw = int.Parse(Tamount);
            if (bal3 > withdraw)
            {
                int rech = bal3 - withdraw;
                try
                {
                    MySqlConnection connection2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                    connection2.Open();
                    String update2 = "UPDATE atm.access SET accountbalance='" + rech + "' Where pin =" + int.Parse(textbox1.Text) + "";
                    MySqlCommand cmmd = new MySqlCommand(update2, connection2);

                    if (cmmd.ExecuteNonQuery() == 1)
                    {
                        MessageBox.Show("sucess  = ", rech.ToString());
                        another.Visible = true;
                        label9.Text = "SUCCESSFUL";
                    }
                    else
                        MessageBox.Show("fail  = ", rech.ToString());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error" + ex);
                }
            }
        }

        private void button56_Click(object sender, EventArgs e)
        {
            Tscreen2.Visible = false;
            Tscreen1.Visible = true;
        }

        private void button62_Click(object sender, EventArgs e)
        {

            MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            connection.Open();
            String select = "Select * from atm.access where accountnumber ='" + int.Parse(textBox5.Text) + "'";
            MySqlCommand cmmd = new MySqlCommand(select, connection);
            MySqlDataReader dr = cmmd.ExecuteReader();
            if (dr.Read())
            {
                Tscreen2.Visible = true;
                label46.Text = (dr["lastname"].ToString() + " " + dr["FirstName"].ToString());
                // label47.Text = (dr["FirstName"].ToString());
            }
            else
            {
                MessageBox.Show("account dont exist");
            }

        }

        private void button19_Click(object sender, EventArgs e)
        {

        }
    }
}